package com.receptionist.user.repository;

import com.receptionist.user.model.Guest;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface GuestRepository extends MongoRepository<Guest , Integer> {

    Guest findById(int id);
}


