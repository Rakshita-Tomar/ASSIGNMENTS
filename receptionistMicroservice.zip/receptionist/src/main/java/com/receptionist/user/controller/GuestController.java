package com.receptionist.user.controller;

import java.util.List;
import java.util.Map;

import com.receptionist.user.model.Guest;
import com.receptionist.user.service.GuestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/reception")
public class GuestController {

    @Autowired
    private GuestService guestService;

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/guests")
    public Guest saveGuest(@RequestBody Guest guest) {
        return guestService.saveGuest(guest);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/guests")
    public List<Guest> getGuests() {
        return guestService.getGuests();
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/guests/{id}")
    public ResponseEntity<Guest> getGuestById(@PathVariable int id) {
        return guestService.getGuestById(id);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PutMapping("/guests/{id}")
    public ResponseEntity<Guest> updateGuest(@PathVariable Integer id, @RequestBody Guest guestDetails) {

        return guestService.updateGuest(id, guestDetails);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @DeleteMapping("/guests/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteGuest(@PathVariable("id") int id) {
        return guestService.deleteGuest(id);

    }
}
