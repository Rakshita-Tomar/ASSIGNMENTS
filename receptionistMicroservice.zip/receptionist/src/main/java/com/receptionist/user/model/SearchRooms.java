//package com.receptionist.user.model;
//
//
//public class SearchRooms {
//
//    private int roomID;
//    private String roomType;
//    private int period;
//    private int checkInTime;
//    private int checkOutTime;
//
//    public SearchRooms() {
//    }
//
//    public SearchRooms(int roomID, String roomType, int period, int checkInTime, int checkOutTime, int roomPrice, int id) {
//        this.roomID = roomID;
//        this.roomType = roomType;
//        this.period = period;
//        this.checkInTime = checkInTime;
//        this.checkOutTime = checkOutTime;
//
//    }
//
//    public int getRoomID() {
//        return roomID;
//    }
//
//    public void setRoomID(int roomID) {
//        this.roomID = roomID;
//    }
//
//    public String getRoomType() {
//        return roomType;
//    }
//
//    public void setRoomType(String roomType) {
//        this.roomType = roomType;
//    }
//
//    public int getPeriod() {
//        return period;
//    }
//
//    public void setPeriod(int period) {
//        this.period = period;
//    }
//
//
//    public int getCheckInTime() {
//        return checkInTime;
//    }
//
//    public void setCheckInTime(int checkInTime) {
//        this.checkInTime = checkInTime;
//    }
//
//    public int getCheckOutTime() {
//        return checkOutTime;
//    }
//
//    public void setCheckOutTime(int checkOutTime) {
//        this.checkOutTime = checkOutTime;
//    }
//}
//
//