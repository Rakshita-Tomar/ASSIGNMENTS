package com.hotel.receptionist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelManageentSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelManageentSystemApplication.class, args);


	}

}
