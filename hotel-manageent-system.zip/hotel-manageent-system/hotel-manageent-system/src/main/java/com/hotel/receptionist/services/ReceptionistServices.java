package com.hotel.receptionist.services;

import com.hotel.receptionist.model.Receptionist;
import com.hotel.receptionist.repository.receptionistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Optional;
@Service
public class ReceptionistServices {

    private receptionistRepository recepRepository;

    @Autowired
    public ReceptionistServices(receptionistRepository recepRepository)
    {
        this.recepRepository=recepRepository;

    }









}
