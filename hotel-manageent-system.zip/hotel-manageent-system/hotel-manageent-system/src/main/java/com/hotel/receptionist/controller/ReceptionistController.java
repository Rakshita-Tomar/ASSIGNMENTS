package com.hotel.receptionist.controller;

import com.hotel.receptionist.exception.ResourceNotFoundException;
import com.hotel.receptionist.model.Receptionist;
import com.hotel.receptionist.repository.receptionistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/receptionist")
public class ReceptionistController {

    @Autowired
    private receptionistRepository repository;

    @PostMapping("/receptionist/addGuest")
    public String addGuest(@RequestBody Receptionist receptionist){

        repository.save(receptionist);
        return "Added User ";
    }
    @GetMapping("/receptionist/findAllGuest")
    public List<Receptionist> getAllGuest(){
        return repository.findAll();
    }

    @GetMapping("/receptionist/findAllGuest/{id}")
    public ResponseEntity<Receptionist> getGuestById(@PathVariable Long id) throws ResourceNotFoundException
    {
    Receptionist Guest=repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Guest does not exist : " +id));
    return ResponseEntity.ok().body(Guest);
    }

    @DeleteMapping("receptionist/delete/{id}")
    public String deleteGuest(@PathVariable Long id){
        repository.deleteById(id);
        return "User data is deleted : " +id;
    }

    @PutMapping("receptionist/update/{id}")
    public ResponseEntity<Receptionist> updateGuest(@PathVariable ("GuestId") Long id , @RequestBody Receptionist details) throws ResourceNotFoundException{
        Receptionist Guest=repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Guest does nor exist : " +id));
        Guest.setEmailId(details.getEmailId());
        Guest.setFirstName(details.getFirstName());
        Guest.setLastName(details.getLastName());
        final Receptionist updateGuest= repository.save(Guest);
        return ResponseEntity.ok(updateGuest);
    }



}
