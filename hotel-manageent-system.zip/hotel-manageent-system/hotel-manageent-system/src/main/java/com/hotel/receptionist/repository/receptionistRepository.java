package com.hotel.receptionist.repository;

import com.hotel.receptionist.model.Receptionist;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;


public interface receptionistRepository extends MongoRepository<Receptionist , Long> {

}
