package com.hotel.owner.controller;

import com.hotel.owner.model.manageStaff;
import com.hotel.owner.services.ManageStaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/manager")
public class manageStaffController {

    @Autowired
    private ManageStaffService manageStaffService;


    @PostMapping("/employee")
    public manageStaff addEmployee(@RequestBody manageStaff manageStafff) {
        return manageStaffService.addEmployee(manageStafff);
    }


    @PutMapping("/employee/{employeeId}")
    public ResponseEntity<manageStaff> editEmployee(@PathVariable Integer employeeId, @RequestBody manageStaff managestaff) {

        return manageStaffService.editEmployee(employeeId, managestaff);

    }


    @DeleteMapping("/employee/{employeeId}")
    public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable("employeeId") int employeeId) {
        return manageStaffService.deleteEmployee(employeeId);
    }
}


