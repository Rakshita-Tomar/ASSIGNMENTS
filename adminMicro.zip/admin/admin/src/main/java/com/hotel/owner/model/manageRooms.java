package com.hotel.owner.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "Manage-Rooms")
public class manageRooms {
    @Id
    private int roomNo;
    @Field
    private String roomType;
    @Field
    private int noOfRooms;
    @Field
    private Double cost;
    @Field
    private String roomImage;

    public manageRooms() {
    }

    public manageRooms(String roomType, int noOfRooms, Double cost, String roomImage) {
        this.roomType = roomType;
        this.noOfRooms = noOfRooms;
        this.cost = cost;
        this.roomImage = roomImage;
    }

    public int getRoomNo() {
        return roomNo;
    }

    public void setRoomNo(int roomNo) {
        this.roomNo = roomNo;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public int getNoOfRooms() {
        return noOfRooms;
    }

    public void setNoOfRooms(int noOfRooms) {
        this.noOfRooms = noOfRooms;
    }

    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

    public String getRoomImage() {
        return roomImage;
    }

    public void setRoomImage(String roomImage) {
        this.roomImage = roomImage;
    }


    @Override
    public String toString() {
        return "manageRooms{" +
                "roomNo=" + roomNo +
                ", roomType='" + roomType + '\'' +
                ", noOfRooms=" + noOfRooms +
                ", cost=" + cost +
                ", roomImage='" + roomImage + '\'' +
                '}';
    }
}
