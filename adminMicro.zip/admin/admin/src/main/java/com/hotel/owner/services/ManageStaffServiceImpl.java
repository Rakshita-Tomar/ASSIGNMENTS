package com.hotel.owner.services;

import com.hotel.owner.model.manageStaff;
import com.hotel.owner.repository.ManageStaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class ManageStaffServiceImpl implements ManageStaffService{

    @Autowired
    private final ManageStaffRepository manageStaffRepository;

    public ManageStaffServiceImpl(ManageStaffRepository manageStaffRepository){
        this.manageStaffRepository=manageStaffRepository;
    }

    @Override
    public manageStaff addEmployee(manageStaff employee) {
        return manageStaffRepository.save(employee);
    }

    @Override
    public ResponseEntity<manageStaff> editEmployee(int id, manageStaff staffDetails) {
        manageStaff manageStaff = manageStaffRepository.findByEmployeeId(id);
        manageStaff.setEmployeeName(manageStaff.getEmployeeName());
        manageStaff.setEmployeeAddress(manageStaff.getEmployeeAddress());
        manageStaff.setEmployeeSalary(manageStaff.getEmployeeSalary());
        manageStaff.setEmployeeEmail(manageStaff.getEmployeeEmail());
        manageStaff manageEmployeeDetails = manageStaffRepository.save(manageStaff);
        return ResponseEntity.ok(manageEmployeeDetails);

    }

    @Override
    public ResponseEntity<Map<String, Boolean>> deleteEmployee(int id) {
        manageStaff deleteEmployee = manageStaffRepository.findByEmployeeId(id);
//                .orElseThrow(() -> new ResourceNotFoundException("Guest does not exist with id :" + id));

        manageStaffRepository.delete(deleteEmployee);
        Map<String, Boolean> response1 = new HashMap<>();
        response1.put("Employee no longer exist", Boolean.TRUE);
        return ResponseEntity.ok(response1);
    }
}
