package com.hotel.owner.services;



import com.hotel.owner.model.manageStaff;
import org.springframework.http.ResponseEntity;

import java.util.Map;

public interface ManageStaffService {
    public manageStaff addEmployee(manageStaff employee);
    public ResponseEntity<manageStaff> editEmployee(int id, manageStaff staffDetails);
    public ResponseEntity<Map<String,Boolean>> deleteEmployee(int id);

}
