package com.hotel.owner.exception;

public class ResourceNotFoundException {
}
