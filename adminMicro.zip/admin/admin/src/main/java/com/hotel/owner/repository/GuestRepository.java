package com.hotel.owner.repository;

import com.hotel.owner.model.Guest;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface GuestRepository extends MongoRepository<Guest, Integer> {

    Guest findById(int id);
}


