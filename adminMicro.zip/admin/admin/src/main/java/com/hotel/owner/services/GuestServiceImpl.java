package com.hotel.owner.services;

import com.hotel.owner.model.Guest;
import com.hotel.owner.repository.GuestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GuestServiceImpl implements GuestService {

    private final GuestRepository guestRepository;

    @Autowired
    public GuestServiceImpl(GuestRepository guestRepository) {
        this.guestRepository = guestRepository;
    }

    @Override
    public Guest saveGuest(Guest guest) {
        return guestRepository.save(guest);
    }

    @Override
    public List<Guest> getGuests() {
        return guestRepository.findAll();
    }

    @Override
    public ResponseEntity<Guest> getGuestById(int id) {
        Guest guest = guestRepository.findById(id);
        return ResponseEntity.ok(guest);
    }

    @Override
    public ResponseEntity<Guest> updateGuest(int id, Guest guestDetails) {
        Guest guest = guestRepository.findById(id);

        guest.setFirstName(guestDetails.getFirstName());
        guest.setLastName(guestDetails.getLastName());
        guest.setEmail(guestDetails.getEmail());
        guest.setContactNo(guestDetails.getContactNo());
        guest.setGender(guestDetails.getGender());
        guest.setAddress(guestDetails.getAddress());
        guest.setCompany(guestDetails.getCompany());
        Guest updatedGuest = guestRepository.save(guest);
        return ResponseEntity.ok(updatedGuest);
    }

    @Override
    public ResponseEntity<Map<String, Boolean>> deleteGuest(int id) {
        Guest guest = guestRepository.findById(id);
//                .orElseThrow(() -> new ResourceNotFoundException("Guest does not exist with id :" + id));

        guestRepository.delete(guest);
        Map<String, Boolean> response1 = new HashMap<>();
        response1.put("Guest no longer exist", Boolean.TRUE);
        return ResponseEntity.ok(response1);    
    }
}

