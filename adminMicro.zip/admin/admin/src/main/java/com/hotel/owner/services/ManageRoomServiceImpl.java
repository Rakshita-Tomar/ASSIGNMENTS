package com.hotel.owner.services;

import com.hotel.owner.model.manageRooms;
import com.hotel.owner.repository.ManageRoomsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class ManageRoomServiceImpl implements ManageRoomsService {

    private final ManageRoomsRepository manageRoomsRepository;

    @Autowired
    public ManageRoomServiceImpl(ManageRoomsRepository manageRoomsRepository) {
        this.manageRoomsRepository = manageRoomsRepository;
    }

    @Override
    public manageRooms addRoom(manageRooms manageRooms) {
        return manageRoomsRepository.save(manageRooms);
    }

    @Override
    public ResponseEntity<manageRooms> editRoom(int roomNo, manageRooms roomDetails) {
        manageRooms manageRooms = manageRoomsRepository.findByRoomNo(roomNo);
        manageRooms.setRoomType(roomDetails.getRoomType());
        manageRooms.setNoOfRooms(roomDetails.getNoOfRooms());
        manageRooms.setCost(roomDetails.getCost());
        manageRooms.setRoomImage(roomDetails.getRoomImage());
        manageRooms manageRooms1 = manageRoomsRepository.save(manageRooms);
        return ResponseEntity.ok(manageRooms1);

    }

    @Override
    public ResponseEntity<Map<String, Boolean>> deleteRoom(int roomNo) {
        manageRooms manageRooms = manageRoomsRepository.findByRoomNo(roomNo);
//                .orElseThrow(() -> new ResourceNotFoundException("Guest does not exist with id :" + id));

        manageRoomsRepository.delete(manageRooms);
        Map<String, Boolean> response1 = new HashMap<>();
        response1.put("Room is deleted", Boolean.TRUE);
        return ResponseEntity.ok(response1);

    }
}
