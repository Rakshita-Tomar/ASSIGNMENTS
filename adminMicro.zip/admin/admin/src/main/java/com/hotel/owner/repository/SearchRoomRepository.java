package com.hotel.owner.repository;


import com.hotel.owner.model.SearchRooms;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface SearchRoomRepository extends MongoRepository<SearchRooms, Integer> {

    SearchRooms findById(int roomNo);
}
