package com.hotel.owner.services;

import com.hotel.owner.model.SearchRooms;
import org.springframework.http.ResponseEntity;
import java.util.List;
import java.util.Map;


public interface SearchRoomService {

    public List<SearchRooms> getRoom();
    public SearchRooms saveRoom(SearchRooms searchRooms);
    public ResponseEntity<SearchRooms> getRoomById(int roomNo);
    public ResponseEntity<SearchRooms> updateRoom(int roomNo, SearchRooms searchRoomsDetails);
    public ResponseEntity<Map<String,Boolean>> deleteRoom(int roomNo);

}


