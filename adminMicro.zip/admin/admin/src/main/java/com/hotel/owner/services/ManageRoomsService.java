package com.hotel.owner.services;


import com.hotel.owner.model.manageRooms;
import org.springframework.http.ResponseEntity;

import java.util.Map;

public interface ManageRoomsService {

    public manageRooms addRoom(manageRooms manageRooms);
    public ResponseEntity<manageRooms> editRoom(int id, manageRooms roomDetails);
    public ResponseEntity<Map<String,Boolean>> deleteRoom(int id);

}
