package com.hotel.owner.services;

import com.hotel.owner.model.Guest;
import org.springframework.http.ResponseEntity;
import java.util.List;
import java.util.Map;

public interface GuestService {

    public List<Guest> getGuests();
    public Guest saveGuest(Guest guest);
    public ResponseEntity<Guest> getGuestById(int id);
    public ResponseEntity<Guest> updateGuest(int id, Guest guestDetails);
    public ResponseEntity<Map<String,Boolean>> deleteGuest(int id);

}
