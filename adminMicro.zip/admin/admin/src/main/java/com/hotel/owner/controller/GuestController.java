package com.hotel.owner.controller;

import com.hotel.owner.model.Guest;
import com.hotel.owner.services.GuestService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/reception")
public class GuestController {

    @Autowired
    private GuestService guestService;

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/guests")
    public Guest saveGuest(@RequestBody Guest guest) {
        return guestService.saveGuest(guest);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/guests")
    public List<Guest> getGuests() {
        return guestService.getGuests();
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/guests/{id}")
    public ResponseEntity<Guest> getGuestById(@PathVariable int id) {
        return guestService.getGuestById(id);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PutMapping("/guests/{id}")
    public ResponseEntity<Guest> updateGuest(@PathVariable Integer id, @RequestBody Guest guestDetails) {

        return guestService.updateGuest(id, guestDetails);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @DeleteMapping("/guests/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteGuest(@PathVariable("id") int id) {
        return guestService.deleteGuest(id);

    }
}
