package com.hotel.owner.repository;

import com.hotel.owner.model.manageRooms;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ManageRoomsRepository extends MongoRepository<manageRooms , Integer> {
     manageRooms findByRoomNo(int roomNo);
}
