package com.hotel.owner.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "Search-Rooms")
public class SearchRooms {
    @Id
    private int roomNo;
    @Field
    private Boolean Availability;
    @Field
    private String roomType;
    @Field
    private int period;
    @Field
    private int checkInTime;
    @Field
    private int checkOutTime;

    public SearchRooms() {
    }

    public SearchRooms(Boolean Availability, String roomType, int period, int checkInTime, int checkOutTime) {
        this.Availability = Availability;
        this.roomType = roomType;
        this.period = period;
        this.checkInTime = checkInTime;
        this.checkOutTime = checkOutTime;
    }

    public int getRoomNo() {
        return roomNo;
    }

    public void setRoomNo(int roomNo) {
        this.roomNo = roomNo;
    }

    public Boolean getAvailability() {
        return Availability;
    }

    public void setAvailability(Boolean availability) {
        Availability = availability;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public int getPeriod() {
        return period;
    }

    public void setPeriod(int period) {
        this.period = period;
    }

    public int getCheckInTime() {
        return checkInTime;
    }

    public void setCheckInTime(int checkInTime) {
        this.checkInTime = checkInTime;
    }

    public int getCheckOutTime() {
        return checkOutTime;
    }

    public void setCheckOutTime(int checkOutTime) {
        this.checkOutTime = checkOutTime;
    }

    @Override
    public String toString() {
        return "SearchRooms{" +
                "roomNo=" + roomNo +
                ", Availability=" + Availability +
                ", roomType='" + roomType + '\'' +
                ", period=" + period +
                ", checkInTime=" + checkInTime +
                ", checkOutTime=" + checkOutTime +
                '}';
    }
}