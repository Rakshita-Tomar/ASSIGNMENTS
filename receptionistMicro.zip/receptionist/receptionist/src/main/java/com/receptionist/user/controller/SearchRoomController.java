package com.receptionist.user.controller;

import com.receptionist.user.model.SearchRooms;
import com.receptionist.user.service.SearchRoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/reception")
public class SearchRoomController {

    @Autowired
    private SearchRoomService searchRoomService;

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/rooms")
    public SearchRooms saveRoom(@RequestBody SearchRooms rooms) {
        return searchRoomService.saveRoom(rooms);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/rooms")
    public List<SearchRooms> getRoom() {
        return searchRoomService.getRoom();
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/rooms/{roomNo}")
    public ResponseEntity<SearchRooms> getRoomById(@PathVariable int roomNo)
    {
        return searchRoomService.getRoomById(roomNo);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PutMapping("/rooms/{roomNo}")
    public ResponseEntity<SearchRooms> updateRoom(@PathVariable Integer roomNo, @RequestBody SearchRooms searchRooms) {

        return searchRoomService.updateRoom(roomNo, searchRooms);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @DeleteMapping("/rooms/{roomNo}")
    public ResponseEntity<Map<String, Boolean>> deleteRoom(@PathVariable("roomNo") int roomNo) {
        return searchRoomService.deleteRoom(roomNo);

    }
}


