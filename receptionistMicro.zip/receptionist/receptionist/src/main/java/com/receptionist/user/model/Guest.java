package com.receptionist.user.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;
import org.springframework.data.mongodb.core.mapping.MongoId;

import javax.annotation.processing.Generated;

@Document(collection = "Receptionist-Guest")
public class Guest {

    @Transient
    public static final String SEQUENCE_NAME = "guest_sequence";

    @Id
    private int id;
    @Field(value = "Guest_First_Name")
    private String firstName;
    @Field(value = "Guest_Last_Name")
    private String lastName;
    @Field(value = "Guest_email")
    private String email;
    @Field(value = "Guest_contact_No")
    private long contactNo;
    @Field(value = "Guest_Gender")
    private String gender;
    @Field(value = "Guest_Address")
    private String address;
    @Field(value = "Guest_Company")
    private String company;
    @Field
    private SearchRooms searchRooms;


    public Guest(String firstName, String lastName, String email, long contactNo, String gender, String address, String company , SearchRooms searchRooms) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.contactNo = contactNo;
        this.gender = gender;
        this.address = address;
        this.company = company;
        this.searchRooms=searchRooms;

    }

    public Guest() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getContactNo() {
        return contactNo;
    }

    public void setContactNo(long contactNo) {
        this.contactNo = contactNo;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public SearchRooms getSearchRooms() {
        return searchRooms;
    }

    public void setSearchRooms(SearchRooms searchRooms) {
        this.searchRooms = searchRooms;
    }

    @Override
    public String toString() {
        return "Guest{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", contactNo=" + contactNo +
                ", gender='" + gender + '\'' +
                ", address='" + address + '\'' +
                ", company='" + company + '\'' +
                ", searchRooms='" + searchRooms + '\'' +
                '}';
    }
}