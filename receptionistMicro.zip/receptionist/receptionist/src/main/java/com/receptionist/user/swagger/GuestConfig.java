package com.receptionist.user.swagger;

public class GuestConfig {
}
