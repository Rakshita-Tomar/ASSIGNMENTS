package com.receptionist.user.service;

import com.receptionist.user.model.SearchRooms;
import com.receptionist.user.repository.SearchRoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SearchRoomServiceImpl implements SearchRoomService {

    @Autowired
    private final SearchRoomRepository searchRoomRepository;

    public SearchRoomServiceImpl(SearchRoomRepository searchRoomRepository) {
        this.searchRoomRepository = searchRoomRepository;
    }

    @Override
    public List<SearchRooms> getRoom() {
        return searchRoomRepository.findAll();
    }

    @Override
    public SearchRooms saveRoom(SearchRooms searchRooms) {
        return searchRoomRepository.save(searchRooms);
    }

    @Override
    public ResponseEntity<SearchRooms> getRoomById(int roomNo) {
        SearchRooms searchRooms = searchRoomRepository.findById(roomNo);
        return ResponseEntity.ok(searchRooms);
    }

    @Override
    public ResponseEntity<SearchRooms> updateRoom(int roomNo, SearchRooms searchRoomsDetails) {
        SearchRooms searchRooms = searchRoomRepository.findById(roomNo);
        searchRooms.setAvailability(searchRoomsDetails.getAvailability());
        searchRooms.setRoomType(searchRoomsDetails.getRoomType());
        searchRooms.setCheckInTime(searchRoomsDetails.getCheckInTime());
        searchRooms.setCheckOutTime(searchRooms.getCheckOutTime());
        searchRooms.setPeriod(searchRoomsDetails.getPeriod());
        SearchRooms searchRooms1 = searchRoomRepository.save(searchRooms);
        return ResponseEntity.ok(searchRooms1);

    }

    @Override
    public ResponseEntity<Map<String, Boolean>> deleteRoom(int roomNo) {
        SearchRooms searchRooms = searchRoomRepository.findById(roomNo);
//                .orElseThrow(() -> new ResourceNotFoundException("Guest does not exist with id :" + id));

        searchRoomRepository.delete(searchRooms);
        Map<String, Boolean> response1 = new HashMap<>();
        response1.put("ROOM GET DELETED", Boolean.TRUE);
        return ResponseEntity.ok(response1);
    }
}
