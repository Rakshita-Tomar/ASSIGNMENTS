package com.hotel.bookRoom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearchRoomsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SearchRoomsApplication.class, args);
	}

}
