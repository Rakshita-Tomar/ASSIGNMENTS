package com.hotel.bookRoom.model;

public class bookRooms {
   private int roomId;
   private String RoomType;
   private int NoOfRooms;
   private Double cost;
   private String roomImage;






}
