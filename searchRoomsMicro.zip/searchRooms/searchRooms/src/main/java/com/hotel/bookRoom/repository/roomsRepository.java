package com.hotel.bookRoom.repository;

public class roomsRepository {
}
