package com.receptionist.user.repository;

import com.receptionist.user.model.Guest;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface GuestRepository extends MongoRepository<Guest , Integer> {
}
