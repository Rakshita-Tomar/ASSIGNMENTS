package com.receptionist.user.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.receptionist.user.exception.ResourceNotFoundException;
import com.receptionist.user.model.Guest;
import com.receptionist.user.repository.GuestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/hotel")
public class GuestController {

    @Autowired
    private GuestRepository guestRepository;

    // get all employees
    @GetMapping("/findGuests")
    public List<Guest> getAllGuest(){
        return guestRepository.findAll();
    }


    @PostMapping("/addGuest")
    public Guest CreateGuest(@RequestBody Guest guest) {
        return guestRepository.save(guest);
    }


    @GetMapping("/findGuestById/{id}")
    public ResponseEntity<Guest> getEmployeeById(@PathVariable Integer id) {
        Guest guest = guestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User does not exist with id ::" + id));
        return ResponseEntity.ok(guest);
    }


    @PutMapping("/updateGuestById/{id}")
    public ResponseEntity<Guest> updateEmployee(@PathVariable Integer id, @RequestBody Guest guestDetails){
       Guest guest = guestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User does not exist with id :" + id));

        guest.setFirstName(guestDetails.getFirstName());
        guest.setLastName(guestDetails.getLastName());
        guest.setEmail(guestDetails.getEmail());
        guest.setContactNo(guestDetails.getContactNo());
        guest.setGender(guestDetails.getGender());
        guest.setAddress(guestDetails.getAddress());
        guest.setCompany(guestDetails.getCompany());

        Guest updatedGuest = guestRepository.save(guest);
        return ResponseEntity.ok(updatedGuest);
    }


    @DeleteMapping("/deleteGuestById/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Integer id){
        Guest guest = guestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Guest does not exist with id :" + id));

        guestRepository.delete(guest);
        Map<String, Boolean> response1 = new HashMap<>();
        response1.put("Guest no longer exist", Boolean.TRUE);
        return ResponseEntity.ok(response1);
    }


}
