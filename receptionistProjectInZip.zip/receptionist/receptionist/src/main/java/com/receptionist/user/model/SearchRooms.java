package com.receptionist.user.model;

import java.util.Date;

public class SearchRooms {

    private int roomID;
    private String roomType;
    private int period;
    private int checkInTime;
    private int checkOutTime;
    private int roomPrice;
    private int id;

    public SearchRooms() {
    }

    public SearchRooms(int roomID, String roomType, int period, int checkInTime, int checkOutTime, int roomPrice, int id) {
        this.roomID = roomID;
        this.roomType = roomType;
        this.period = period;
        this.checkInTime = checkInTime;
        this.checkOutTime = checkOutTime;
        this.roomPrice = roomPrice;
        this.id = id;
    }

    public int getRoomID() {
        return roomID;
    }

    public void setRoomID(int roomID) {
        this.roomID = roomID;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public int getPeriod() {
        return period;
    }

    public void setPeriod(int period) {
        this.period = period;
    }

    public int getCheckInTime() {
        return checkInTime;
    }

    public void setCheckInTime(int checkInTime) {
        this.checkInTime = checkInTime;
    }

    public int getCheckOutTime() {
        return checkOutTime;
    }

    public void setCheckOutTime(int checkOutTime) {
        this.checkOutTime = checkOutTime;
    }

    public int getRoomPrice() {
        return roomPrice;
    }

    public void setRoomPrice(int roomPrice) {
        this.roomPrice = roomPrice;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
