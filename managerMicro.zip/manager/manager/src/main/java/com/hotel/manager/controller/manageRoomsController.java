package com.hotel.manager.controller;

import com.hotel.manager.model.manageRooms;
import com.hotel.manager.service.ManageRoomsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/manager")
public class manageRoomsController {

    @Autowired
    private ManageRoomsService manageRoomsService;

    @GetMapping("/rooms")
    public List<manageRooms> getRooms() {
        return manageRoomsService.getRoom();
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/rooms/{roomNo}")
    public ResponseEntity<manageRooms> findByRoomNo(@PathVariable int roomNo) {
        return manageRoomsService.findByRoomNo(roomNo);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/rooms")
    public manageRooms addRoom(@RequestBody manageRooms manageRooms) {
        return manageRoomsService.addRoom(manageRooms);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PutMapping("/rooms/{roomNo}")
    public ResponseEntity<manageRooms> editRoom(@PathVariable Integer roomNo, @RequestBody manageRooms manageRooms) {

        return manageRoomsService.editRoom(roomNo, manageRooms);

    }

    @CrossOrigin(origins = "http://localhost:4200")
    @DeleteMapping("/rooms/{roomNo}")
    public ResponseEntity<Map<String, Boolean>> deleteRoom(@PathVariable("roomNo") int roomNo) {
        return manageRoomsService.deleteRoom(roomNo);
    }
}
