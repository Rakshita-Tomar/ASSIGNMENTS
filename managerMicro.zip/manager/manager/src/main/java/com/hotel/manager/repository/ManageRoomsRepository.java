package com.hotel.manager.repository;

import com.hotel.manager.model.manageRooms;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ManageRoomsRepository extends MongoRepository<manageRooms , Integer> {
     manageRooms findByRoomNo(int roomNo);
}
