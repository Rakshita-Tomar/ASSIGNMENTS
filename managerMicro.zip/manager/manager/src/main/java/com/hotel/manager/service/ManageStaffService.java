package com.hotel.manager.service;


import com.hotel.manager.model.manageStaff;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

public interface ManageStaffService {
    public manageStaff addEmployee(manageStaff employee);
    public ResponseEntity<manageStaff> editEmployee(int employeeId, manageStaff staffDetails);
    public ResponseEntity<Map<String,Boolean>> deleteEmployee(int employeeId);
    public List<manageStaff> getEmployee();
    public ResponseEntity<manageStaff> getEmployeeById(int employeeId);
}
