package com.hotel.manager.repository;


import com.hotel.manager.model.manageStaff;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ManageStaffRepository extends MongoRepository<manageStaff, Integer> {
    manageStaff findById(int employeeId);
}
