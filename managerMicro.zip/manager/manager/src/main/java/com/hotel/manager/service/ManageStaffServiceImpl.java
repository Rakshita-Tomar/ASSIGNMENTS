package com.hotel.manager.service;

import com.hotel.manager.model.manageStaff;
import com.hotel.manager.repository.ManageStaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ManageStaffServiceImpl implements ManageStaffService{

    @Autowired
    private final ManageStaffRepository manageStaffRepository;

    public ManageStaffServiceImpl(ManageStaffRepository manageStaffRepository){
        this.manageStaffRepository=manageStaffRepository;
    }

    @Override
    public manageStaff addEmployee(manageStaff employee) {
        return manageStaffRepository.save(employee);
    }

    @Override
    public ResponseEntity<manageStaff> editEmployee(int employeeId, manageStaff staffDetails) {
        manageStaff manageStaff1 = manageStaffRepository.findById(employeeId);
        manageStaff1.setEmployeeName(staffDetails.getEmployeeName());
        manageStaff1.setEmployeeAddress(staffDetails.getEmployeeAddress());
        manageStaff1.setEmployeeSalary(staffDetails.getEmployeeSalary());
        manageStaff1.setEmployeeEmail(staffDetails.getEmployeeEmail());
        manageStaff manageEmployeeDetails = manageStaffRepository.save(manageStaff1);
        return ResponseEntity.ok(manageEmployeeDetails);

    }

    @Override
    public ResponseEntity<Map<String, Boolean>> deleteEmployee(int employeeId) {
        manageStaff deleteEmployee = manageStaffRepository.findById(employeeId);
//                .orElseThrow(() -> new ResourceNotFoundException("Guest does not exist with id :" + id));

        manageStaffRepository.delete(deleteEmployee);
        Map<String, Boolean> response1 = new HashMap<>();
        response1.put("Employee no longer exist", Boolean.TRUE);
        return ResponseEntity.ok(response1);
    }

    @Override
    public List<manageStaff> getEmployee() {
        return manageStaffRepository.findAll();
    }

    @Override
    public ResponseEntity<manageStaff> getEmployeeById(int employeeId) {
        manageStaff manageStaff1 = manageStaffRepository.findById(employeeId);
        return ResponseEntity.ok(manageStaff1);
    }
}
