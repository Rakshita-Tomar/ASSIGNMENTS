package com.hotel.manager.controller;

import com.hotel.manager.model.manageStaff;
import com.hotel.manager.service.ManageStaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
@RestController
@RequestMapping("/manager")
public class manageStaffController {

    @Autowired
    private ManageStaffService manageStaffService;

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/employees")
    public List<manageStaff> getEmployee() {
        return manageStaffService.getEmployee();
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/employees/{id}")
    public ResponseEntity<manageStaff> getEmployeeById(@PathVariable int id) {
        return manageStaffService.getEmployeeById(id);
    }


    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/employees")
    public manageStaff addEmployee(@RequestBody manageStaff manageStafff) {
        return manageStaffService.addEmployee(manageStafff);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PutMapping("/employees/{employeeId}")
    public ResponseEntity<manageStaff> editEmployee(@PathVariable("employeeId") Integer employeeId, @RequestBody manageStaff managestaff) {

        return manageStaffService.editEmployee(employeeId, managestaff);

    }

    @CrossOrigin(origins = "http://localhost:4200")
    @DeleteMapping("/employees/{employeeId}")
    public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable("employeeId") int employeeId) {
        return manageStaffService.deleteEmployee(employeeId);
    }
}


