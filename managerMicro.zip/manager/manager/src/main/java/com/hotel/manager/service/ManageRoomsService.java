package com.hotel.manager.service;

import com.hotel.manager.model.manageRooms;
import com.hotel.manager.model.manageStaff;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

public interface ManageRoomsService {

    public manageRooms addRoom(manageRooms manageRooms);
    public ResponseEntity<manageRooms> editRoom(int id, manageRooms roomDetails);
    public ResponseEntity<Map<String,Boolean>> deleteRoom(int id);
    public List<manageRooms> getRoom();
    public ResponseEntity<manageRooms> findByRoomNo(int roomNo);

}
